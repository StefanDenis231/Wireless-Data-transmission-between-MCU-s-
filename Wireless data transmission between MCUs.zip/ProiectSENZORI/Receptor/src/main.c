/*********************************************************
* MAIN
*********************************************************/
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>

#define F_CPU 16000000UL  
#define BAUD 9600
#define BRC ((F_CPU/16/BAUD) - 1)

volatile uint8_t transmision_start;
volatile uint8_t counter;
volatile uint8_t send_bit_msg;
volatile uint8_t recieved_caracter;

/*********************************************************
* PROTOTYPES
*********************************************************/
//UART AND SERIAL DATA
void USART_init(void);
void USART_transmit(char data);
static int usart_putchar_printf(char var, FILE *stream);

//Setup D2 interrupt (on rising edge) and set D2 as input
void set_D2_interrupt();
//Falling edge interrupt in D3 for data transmision start
void set_D3_interrupt();

//ADC
void ADC_init();
uint16_t read_ADC(uint8_t channel);

/*********************************************************
* MAIN
*********************************************************/
int main (void) 
{
    
     USART_init();

    // Override put char to be able to use printf
    static FILE USART_output = FDEV_SETUP_STREAM(usart_putchar_printf, NULL, _FDEV_SETUP_WRITE);
    stdout = &USART_output;

    //set D2 interrupt
    set_D2_interrupt();
    //set D3 interrupt (falling edge)
    set_D3_interrupt();

    //enable global interrupts
    sei();

    //init adc
    ADC_init();
    printf("Start\n");

    transmision_start = 0;

    counter = 0;

    send_bit_msg = 0;

    recieved_caracter = 0;

    while(1) 
    {
        
        
        

    }
}

void USART_init(void) 
{
    UBRR0H = (BRC >> 8);
    UBRR0L = BRC;
    UCSR0B = (1 << RXEN0) | (1 << TXEN0);
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void USART_transmit(char data) 
{
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

static int usart_putchar_printf(char var, FILE *stream) 
{
    if (var == '\n') USART_transmit('\r');
    USART_transmit(var);
    return 0;
}

void set_D2_interrupt()
{
    // Set up D2 (INT0) as an input
    DDRD &= ~(1 << DDD2);

    // Enable pull-up resistor on D2
    PORTD |= (1 << PORTD2);

    // Enable external interrupt on INT0 (D2) for rising edge
    EICRA |= (1 << ISC01) | (1 << ISC00); // Set rising edge trigger
    EIMSK |= (1 << INT0);                // Enable INT0
}

void set_D3_interrupt()
{
    // Configure the external interrupt for falling edge
    EICRA |= (1 << ISC11);
    EICRA &= ~(1 << ISC10);

    // Enable external interrupt INT1
    EIMSK |= (1 << INT1);

}

void ADC_init() 
{
    // Set the reference voltage to AVcc (5V)
    ADMUX |= (1 << REFS0);

    // Enable the ADC and set the prescaler to 128
    // ADC clock frequency is 16 MHz divided by 128 = 125 KHz
    ADCSRA |= (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

uint16_t read_ADC(uint8_t channel)
{
    // Select the ADC channel to read
    ADMUX = (ADMUX & 0xF8) | (channel & 0x07);

    // Start the ADC conversion
    ADCSRA |= (1 << ADSC);

    // Wait for the conversion to finish
    while (ADCSRA & (1 << ADSC));

    // Return the ADC value
    return (ADC);
}

/*********************************************************
* ISR
*********************************************************/
// Interrupt Service Routine for INT0
ISR(INT0_vect) 
{
    if(transmision_start == 1)
    {
        if(counter < 8)
        {
            if(send_bit_msg == 0)
            {
                printf("Cei 8 biti primiti: \n");
                send_bit_msg = 1;
            }
            counter++;
            uint16_t led_light = read_ADC(0);
            uint8_t recieved_bit;
            if(led_light > 150)
            {
                recieved_bit = 1;
            }
            else
            {
                recieved_bit = 0;
            }

            recieved_caracter |= recieved_bit;
            if(counter < 8)
            {
                recieved_caracter = recieved_caracter << 1;
            }
            
            printf("%d", recieved_bit, counter);
            if(counter == 8)
            {
                printf("\nCaracterul primit este: %c\n", recieved_caracter);
                send_bit_msg = 0;
            }
        }

        if(counter >= 8)
        {
            
            _delay_ms(1000);
            
            uint16_t led_light = read_ADC(0);
            if(led_light > 250)
            {
                transmision_start = 0;
                counter = 0;
            }
        }
    }
    
}

ISR(INT1_vect) {
    if(transmision_start == 0)
    {
        transmision_start = 1;
        recieved_caracter = 0;
    }
}

