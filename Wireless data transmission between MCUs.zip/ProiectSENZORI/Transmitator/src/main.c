#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>

#define MS_DELAY 3000
#define CHAR_BYTE_PAUSE 1000
#define INIT_DELAY 300

#define F_CPU 16000000UL 
#define BAUD 9600
#define BRC ((F_CPU/16/BAUD) - 1)

void send_char_to_led(const char caracter);
void gpio_init();
void protocol_init();


void USART_init(void);
void USART_transmit(char data);
static int usart_putchar_printf(char var, FILE *stream);
unsigned char USART_Receive(void);

int main (void) 
{
    gpio_init();

    protocol_init();

    USART_init();
    static FILE USART_output = FDEV_SETUP_STREAM(usart_putchar_printf, NULL, _FDEV_SETUP_WRITE);
    stdout = &USART_output;
    while(1) 
    {
        printf("Introduceti un caracter: ");
        char char_to_be_send = USART_Receive();
        send_char_to_led(char_to_be_send);
    }
}

void send_char_to_led(const char caracter)
{

    PORTB &= ~(1 << PORTB2);  
    _delay_ms(INIT_DELAY);
    PORTB &= ~(1 << PORTB3);
    _delay_ms(1000);

    for (int i = 7; i >= 0; i--) 
    {
        
        if((caracter >> i) & 1)
        {
            PORTB |= (1 << PORTB2);  
            printf("1");
        }
        else
        {
            PORTB &= ~(1 << PORTB2); 
            printf("0");
        }
        _delay_ms(50);
        PORTB |= (1 << PORTB3);
       
        _delay_ms(CHAR_BYTE_PAUSE);
        PORTB &= ~(1 << PORTB3);
        _delay_ms(CHAR_BYTE_PAUSE);
    }
    printf("\n");

    PORTB |= (1 << PORTB3);
    _delay_ms(INIT_DELAY);
    PORTB |= (1 << PORTB2);
}

void gpio_init()
{
    DDRB |= (1 << DDB3) | (1 << DDB2);
}

void protocol_init()
{
    PORTB |= (1 << PORTB2);
    PORTB |= (1 << PORTB3);
}

void USART_init(void) 
{
    // Set baud rate
    UBRR0H = (unsigned char)(BRC >> 8);
    UBRR0L = (unsigned char)BRC;

    // Enable receiver and transmitter
    UCSR0B = (1 << RXEN0) | (1 << TXEN0);

    // Set frame format: 8 data bits, 1 stop bit
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void USART_transmit(char data) 
{
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

unsigned char USART_Receive(void) {
    // Wait for data to be received
    while (!(UCSR0A & (1 << RXC0)))
    {
        
    }

    // Get and return received data from buffer
    return UDR0;
}

static int usart_putchar_printf(char var, FILE *stream) 
{
    if (var == '\n') USART_transmit('\r');
    USART_transmit(var);
    return 0;
}